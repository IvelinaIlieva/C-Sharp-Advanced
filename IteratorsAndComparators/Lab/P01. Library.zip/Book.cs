﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IteratorsAndComparators
{
    public class Book
    {
        private string title;
        private int year;
        private IReadOnlyList<string> author;

        public string Title { get => title; set => title = value; }

        public int Year { get => year; set => year = value; }

        public IReadOnlyList<string> Author { get => author; set => author = value; }

        public Book(string title, int year, params string[] author)
        {
            Title = title;
            Year = year;
            Author = author;
        }
    }
}
