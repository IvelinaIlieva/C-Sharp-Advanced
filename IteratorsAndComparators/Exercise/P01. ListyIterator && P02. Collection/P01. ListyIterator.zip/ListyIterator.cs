﻿using System;
using System.Collections.Generic;

namespace IteratorsAndComparators
{
    public class ListyIterator<T>
    {
        private List<T> list;
        private int index;

        public List<T> List { get => list; set => list = value; }

        public int Index = 0;

        public ListyIterator(params T[] arr)
        {
            this.List = new List<T>(arr);
            this.index = 0;
        }

        public bool Move()
        {
            if (HasNext())
            {
                index++;
                return true;
            }
            return false;
        }

        public bool HasNext() => index < list.Count - 1;
        
        public void Print()=> Console.WriteLine(list.Count == 0 ? "Invalid Operation!" : list[index].ToString());
    }
}
