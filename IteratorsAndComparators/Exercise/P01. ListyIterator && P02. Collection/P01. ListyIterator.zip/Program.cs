﻿using System;
using System.Linq;

namespace IteratorsAndComparators
{
    public class Program
    {
        static void Main()
        {
            ListyIterator<string> list = new ListyIterator<string>();

            string cmd;
            while ((cmd = Console.ReadLine()) != "END")
            {
                string[] cmdArgs = cmd.Split(' ', StringSplitOptions.RemoveEmptyEntries);

                if (cmd.StartsWith("Create"))
                {
                    list = new ListyIterator<string>(cmdArgs.Skip(1).ToArray());
                }
                else if (cmd.StartsWith("Move"))
                {
                    Console.WriteLine(list.Move());
                }
                else if (cmd.StartsWith("HasNext"))
                {
                    Console.WriteLine(list.HasNext());
                }
                else if (cmd.StartsWith("Print"))
                {
                    list.Print();
                }
            }
        }
    }
}
