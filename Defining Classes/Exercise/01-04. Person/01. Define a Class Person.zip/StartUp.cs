﻿using System;
using System.Runtime.CompilerServices;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person();
            person.Name = "Peter";
            person.Age = 20;

            Person person1 = new Person()
            {
                Name = "George",
                Age = 18
            };

        }
    }
}
