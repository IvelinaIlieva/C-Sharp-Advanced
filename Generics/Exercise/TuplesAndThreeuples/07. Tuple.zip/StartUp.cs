﻿using System;

namespace TuplesAndThreeuples
{
    public class StartUp
    {
        static void Main()
        {
            for (int i = 1; i <= 3; i++)
            {
                string[] input = Console.ReadLine().Split();

                switch (i)
                {
                    case 1:
                        var name1 = input[0] + " " + input[1];
                        var address = input[2];
                        MyTuple<string, string> tuple1 = new MyTuple<string, string>(name1, address);
                        Console.WriteLine(tuple1);
                        break;

                    case 2:
                        var name2 = input[0];
                        var litters = int.Parse(input[1]);
                        MyTuple<string, int> tuple2 = new MyTuple<string, int>(name2, litters);
                        Console.WriteLine(tuple2);
                        break;

                    case 3:
                        var intNum = int.Parse(input[0]);
                        var doubleNum = double.Parse(input[1]);
                        MyTuple<int, double> tuple3 = new MyTuple<int, double>(intNum, doubleNum);
                        Console.WriteLine(tuple3);
                        break;
                }
            }
        }
    }
}
