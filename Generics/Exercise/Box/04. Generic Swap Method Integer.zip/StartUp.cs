﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Channels;

namespace Box
{
    public class StartUp
    {
        static void Main()
        {
            int count = int.Parse(Console.ReadLine());

            List<int> list = new List<int>();

            for (int i = 0; i < count; i++)
            {
                var input = int.Parse(Console.ReadLine());
                list.Add(input);
            }

            Box<int> box = new Box<int>(list);

            int[] indexes = Console.ReadLine().Split().Select(int.Parse).ToArray();

            Box<int>.Swap(list, indexes[0], indexes[1]);
            
            Console.WriteLine(box);

        }
    }
}
